CREATE TABLE "orders" (
	"id" serial PRIMARY KEY,
	"order_code" text NOT NULL,
	"game" text NOT NULL,
	"player_id" text,
	"package_name" text NOT NULL,
	"amount_cop" integer NOT NULL,
	"reference" text NOT NULL,
	"payment_method" text DEFAULT 'Nequi' NOT NULL,
	"has_receipt" boolean DEFAULT false NOT NULL,
	"status" text DEFAULT 'Reporte enviado' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
